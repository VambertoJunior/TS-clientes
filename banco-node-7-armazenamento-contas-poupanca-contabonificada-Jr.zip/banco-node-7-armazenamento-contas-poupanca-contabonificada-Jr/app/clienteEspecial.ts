class ClienteEspecial extends Cliente {
    private clie_conta: Array<Cliente>;

    constructor(nome: string, cpf: string) {
        super(nome, cpf);
    }

    adicionar(clie_conta: Cliente){
        this.clie_conta = clie_conta;
    }

    listaCli(): Array<Cliente>{
        reutrn this.clie_conta;

    }
}