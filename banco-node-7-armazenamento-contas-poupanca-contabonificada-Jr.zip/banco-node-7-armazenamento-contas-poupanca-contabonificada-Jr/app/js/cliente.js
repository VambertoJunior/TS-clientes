class Cliente {
    constructor(nome, cpf, conta) {
        this._nome = nome;
        this.cpf = cpf;
        this.conta = conta;
    }
}
