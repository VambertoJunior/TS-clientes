class Clientes {
    constructor() {
        this.conta = new Array();
        this.conta.push();
    }
    inserir(conta) {
        this.conta.push(conta);
    }
}
