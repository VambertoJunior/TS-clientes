let contaController = new ContaController();

contaController.listar();

const c1 = new Conta('1', 100);
const p1 = new Poupanca('2', 100);
const cb1 = new ContaBonificada('3', 0);

console.log('Conta: ' + c1.saldo);

p1.atualizarSaldoAniversario();
console.log('Poupanca: ' + p1.saldo);

cb1.creditar(100);
console.log('Conta Bonificada: ' + cb1.saldo);


const cli1 = new Cliente('Vamberto', '010.010.200-20', c1);
const cli2 = new Cliente('Gust', '018.819.255-12', p1);
const cli3 = new Cliente('Alex', '089.215.234-35', cb1);

const clientes = new Clientes();
clientes.inserir(cli1);
console.log(clientes.listar());
console.log('010.010.200-20');
console.log('089.215.234-35');


