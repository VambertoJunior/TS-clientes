class ClienteController{
    private inputNome: HTMLInputElement;
    private inputCpf: HTMLInputElement;
    private conta: Clientes;

    constructor() {
        this.inputNome =
            <HTMLInputElement>document.querySelector("#nome")
        this.inputCpf =
            <HTMLInputElement>document.querySelector("#cpf");
        this.conta = new Clientes();
    }

    inserir(evento: Event) {
        evento.preventDefault();
        let cli = new Clientes(this.inputNome.value, this.inputCpf.value, this.conta.value);
        this.conta.inserir(cli);
    }

    listar() {
        this.conta.listar().forEach
    }
    

}