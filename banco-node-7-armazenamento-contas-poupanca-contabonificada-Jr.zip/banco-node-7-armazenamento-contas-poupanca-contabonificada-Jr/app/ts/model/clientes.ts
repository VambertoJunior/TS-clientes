class Clientes{

    private conta: Array<Clientes>;
    cpf: string;

    constructor() {
        this.conta = new Array<Clientes>();
        this.conta.push();
    }

    inserir(conta: Clientes): void {
        this.conta.push(conta);
    }

    remover(cpf: string): void {
        const cpf_remover = this.pesquisa(cpf);
        if (cpf_remover) {
            const indiceConta = this.conta.indexOf(cpf_remover);
            if (indiceConta > -1) {
                this.conta.splice(indiceConta, 1);
            }
        }
    }

    pesquisa(cpf: string): Clientes {
        return this.conta.find(
            conta => conta.cpf === cpf
        );
    }

    listar(): Array<Clientes> {
        return this.conta;
    }
}